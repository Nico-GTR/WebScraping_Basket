# -*- coding: utf-8 -*-
"""
    Installation des modules nécessaires pour pouvoir récupérer les informations
    sur les joueurs et les équipes.
"""
import subprocess
import sys

def installer_modules():
    """
    Installe les modules nécessaires pour les fichiers equipes et joueurs.
    
    Parameters
    ----------
    None
    
    Returns
    -------
    None.

    """
    modules = [
        "requests",
        "pandas",
        "basketball-reference-scraper",
        "selenium",
        "webdriver-manager",
        "bs4",
        "matplotlib",
        'Jinja2'
    ]

    for module in modules:
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", module])
            print(f"Module {module} installé avec succès.")
        except subprocess.CalledProcessError as e:
            print(f"Erreur lors de l'installation du module {module} : {e}")


if __name__ == "__main__":
    installer_modules()
